package com.example.analyzer;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void startMicrobench(View view) {
        try {
            Runtime.getRuntime().exec("logcat -b all -c");

            EditText dataSizeView = findViewById(R.id.data_size_input_id);
            int dataSize = Integer.parseInt(dataSizeView.getText().toString());

            EditText readPercntageView = findViewById(R.id.read_percentage_input_id);
            int readPercentage = Integer.parseInt(readPercntageView.getText().toString());

            Log.d("data size", "" + dataSize);
            Log.d("read percentage", "" + readPercentage);
            runMicrobenchmark(dataSize,readPercentage);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void runMicrobenchmark(int dataSize, int readPercentage) {
        try {
            Toast.makeText(getApplicationContext(), "Benchmark is running...", Toast.LENGTH_SHORT).show();
            LocalDateTime now = LocalDateTime.now();
            Microbenchmark mic = new Microbenchmark(dataSize);
            mic.examineGc(dataSize, readPercentage, 100);

            isWriteStoragePermissionGranted();
            //-d	Dumps the log to the screen and exits.
//            Process process = Runtime.getRuntime().exec("logcat -d");
            String[] cmd = new String[]{"logcat", "-d", "com.example.analyzer:V", "-t", now.toString().replace('T', ' ')};
            Process process = Runtime.getRuntime().exec(cmd);
            makeLogfile(process, now.getMonthValue() + "-" + now.getDayOfMonth() + "-" + now.getHour() + ":" + now.getMinute() + "-"
                    + dataSize + "-" + readPercentage);
            //clear logcat file
            Runtime.getRuntime().exec("logcat -c");
            Toast.makeText(getApplicationContext(), "Done!", Toast.LENGTH_SHORT).show();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void makeLogfile(Process process, String filename) throws IOException {
        BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(process.getInputStream()));
        StringBuilder log = new StringBuilder();
        String filePath= getExternalFilesDir(null).getAbsolutePath();
//        File dir = new File("/sdcard/LogFile");

        String line;
        while ((line = bufferedReader.readLine()) != null)
            if (line.contains("GC") || line.contains("System")) {
                log.append(line);
                log.append("\n");
            }
        File root = new File(filePath, "Logs");
        if (!root.exists()) {
            root.mkdirs();
        }
        File file = new File(root, filename + ".txt");
        FileWriter writer = new FileWriter(file);
        writer.append(log.toString());
        writer.flush();
        writer.close();
        Toast.makeText(getApplicationContext(), "Log files saved", Toast.LENGTH_SHORT).show();

    }

    public boolean isReadStoragePermissionGranted() {
        if (Build.VERSION.SDK_INT >= 23) {
            if (checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE)
                    == PackageManager.PERMISSION_GRANTED) {
                return true;
            } else {
                ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, 3);
                return false;
            }
        } else { //permission is automatically granted on sdk<23 upon installation
            return true;
        }
    }

    public boolean isWriteStoragePermissionGranted() {
        if (Build.VERSION.SDK_INT >= 23) {
            if (checkSelfPermission(android.Manifest.permission.WRITE_EXTERNAL_STORAGE)
                    == PackageManager.PERMISSION_GRANTED) {
                return true;
            } else {
                ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, 2);
                return false;
            }
        } else { //permission is automatically granted on sdk<23 upon installation
            return true;
        }
    }

    public void runAll(View view) {
        List<Integer> percentage= Arrays.asList(25,50,75,100);
        for(int dataSize=1; dataSize<3; dataSize++){
            for(int read:percentage){
                runMicrobenchmark(dataSize,read);
            }
        }
    }
}