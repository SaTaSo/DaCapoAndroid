package com.example.analyzer;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class Spinner extends AppCompatActivity implements AdapterView.OnItemSelectedListener{
    private List<String> logFileNames = new ArrayList();
    private String selectedLogFile="";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        android.widget.Spinner logSpinner = null;//(android.widget.Spinner) findViewById(R.id.spinner_log_files);
        fillSpinner(logSpinner);
    }

    public void startMicrobench(View view) {
        try {
            Runtime.getRuntime().exec("logcat -b all -c");

            EditText dataSizeView = findViewById(R.id.data_size_input_id);
            int dataSize = Integer.parseInt(dataSizeView.getText().toString());

            EditText readPercntageView = findViewById(R.id.read_percentage_input_id);
            int readPercentage = Integer.parseInt(readPercntageView.getText().toString());

            Log.d("data size", "" + dataSize);
            Log.d("read percentage", "" + readPercentage);
            LocalDateTime now = LocalDateTime.now();
            Microbenchmark mic = new Microbenchmark(dataSize);
            mic.examineGc(dataSize, readPercentage, 100);

            isWriteStoragePermissionGranted();
            //-d	Dumps the log to the screen and exits.
//            Process process = Runtime.getRuntime().exec("logcat -d");
            String[] cmd = new String[]{"logcat", "-d", "com.example.analyzer:V", "-t", now.toString().replace('T', ' ')};
            Process process = Runtime.getRuntime().exec(cmd);
            makeLogfile(process, now.getMonthValue()+"-"+now.getDayOfMonth()+" "+now.getHour()+":"+now.getMinute()+"-"
                    +dataSize+"-"+readPercentage+"%");
            //clear logcat file
            Runtime.getRuntime().exec("logcat -c");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void makeLogfile(Process process, String filename) throws IOException {
        BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(process.getInputStream()));
        StringBuilder log = new StringBuilder();
//        File dir = new File("/sdcard/LogFile");

        String line;
        while ((line = bufferedReader.readLine()) != null)
            if (line.contains("GC") || line.contains("System")) {
                log.append(line);
                log.append("\n");
            }
        File root = new File(getExternalFilesDir(null).getAbsolutePath(), "Logs");
        if (!root.exists()) {
            root.mkdirs();
        }
        File file = new File(root,  filename + ".txt");
        FileWriter writer = new FileWriter(file);
        writer.append(log.toString());
        writer.flush();
        writer.close();
        //Toast.makeText(context, "Saved", Toast.LENGTH_SHORT).show();

    }

    public boolean isReadStoragePermissionGranted() {
        if (Build.VERSION.SDK_INT >= 23) {
            if (checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE)
                    == PackageManager.PERMISSION_GRANTED) {
                return true;
            } else {
                ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, 3);
                return false;
            }
        } else { //permission is automatically granted on sdk<23 upon installation
            return true;
        }
    }

    public boolean isWriteStoragePermissionGranted() {
        if (Build.VERSION.SDK_INT >= 23) {
            if (checkSelfPermission(android.Manifest.permission.WRITE_EXTERNAL_STORAGE)
                    == PackageManager.PERMISSION_GRANTED) {
                return true;
            } else {
                ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, 2);
                return false;
            }
        } else { //permission is automatically granted on sdk<23 upon installation
            return true;
        }
    }

    public void fillSpinner(android.widget.Spinner logSpinner) {

        Stream<Path> list = null;
        try {
            list = Files.list(Paths.get(getExternalFilesDir(null).getAbsolutePath() + "/Logs"));

            if (list != null) {
                logFileNames = list.map(a -> a.getFileName().toString()).collect(Collectors.toList());
            }
//        File logFolder = new File(getExternalFilesDir(null).getAbsolutePath() + "/Logs");
            ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item, logFileNames);
// Specify the layout to use when the list of choices appears
            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
// Apply the adapter to the spinner
            logSpinner.setAdapter(adapter);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        selectedLogFile = logFileNames.get(position);
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {
        selectedLogFile= logFileNames.get(0);
    }

    public void runAll(View view) {

    }
}
