package com.example.analyzer;

import android.util.Log;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintStream;
import java.nio.ByteBuffer;
import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Random;
import java.util.Timer;
import java.util.TimerTask;

public class Microbenchmark {

    static int objectSize = 1;

    HashMap<String, GenericObject> population;


    public Microbenchmark(int datasize) {

        population = new HashMap<>();

        for (int i = 0; i < datasize; i++) {
            population.put(String.valueOf(i), new GenericObject(i));
        }
    }

    @SuppressWarnings("UseSpecificCatch")
    public void examineGc(int data, int read, int ops) {
        Log.i("Analyzer", "start app");
        LocalDateTime from = LocalDateTime.now();
        System.out.println("start: " + from);
        try {
            int dataSize = data * 100000;
            int readPercentage = read;
            int nOperations = ops * 100000;

            Random rand = new Random();
            ByteBuffer bufferPercentage = ByteBuffer.allocateDirect(nOperations * 4);
            ByteBuffer bufferAccess = ByteBuffer.allocateDirect(nOperations * 4);
            for (long i = 0; i < nOperations; i++) {
                bufferPercentage.putInt(rand.nextInt(100));
                bufferAccess.putInt(rand.nextInt(dataSize - 1));
            }
            bufferPercentage.flip();
            bufferAccess.flip();

            Microbenchmark dataSet = new Microbenchmark(dataSize);

            // Timed task each 10s that prints the throughput in that time span
            RemindTask rmdtask = new RemindTask();
            Timer timer = new Timer(true);
            timer.scheduleAtFixedRate(rmdtask, 10000, 10000);

            for (int i = 0; i < nOperations; i++) {
                // Get the element to perform the read/write operation upon

                int ss = bufferAccess.getInt();
                if (bufferPercentage.getInt() < readPercentage) {
                    // Read Operation
                    GenericObject object = dataSet.population.
                            get(String.valueOf(ss));
                } else {
                    // Write Operation

                    dataSet.population.put(String.valueOf(ss), new GenericObject(ss));
                }
                rmdtask.counter++;
            }
            LocalDateTime to = LocalDateTime.now();
            long exeTime = ChronoUnit.MILLIS.between(from, to);
            timer.cancel();
            timer.purge();
            //System.setErr(original);
            double mean = ((nOperations / rmdtask.timer) * 1000);
            System.out.println("[Mean/s] Throughput : " + mean);

            System.out.println("end: " + to);
            System.out.println("execution time " + ChronoUnit.MILLIS.between(from, to));

            Log.d("Execution Time", Long.toString(exeTime));
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    static class GenericObject {

        public long[] obj;
        public int number;

        public GenericObject(int value) {
            obj = new long[128 * objectSize];
            number = value;
        }
    }

    static class RemindTask extends TimerTask {
        public int counter = 0;
        public int timer = 0;
        public int interval = 0;

        @Override
        public void run() {
            interval++;
            timer += 10000;
            System.out.println("[" + timer / 1000 + "s] Throughput: " + counter);
            counter = 0;
        }
    }
}
