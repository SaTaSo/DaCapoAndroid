/*
 * Copyright (c) 2011, 2018 Purdue University.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package etalon.purdue.edu.base.wrapper;

import java.io.File;
import java.io.FileDescriptor;
import java.io.FileNotFoundException;

/**
 * @author hussein
 *
 */
public class FileInputStream extends java.io.FileInputStream {

	/**
	 * @param file
	 * @throws FileNotFoundException
	 */
	public FileInputStream(File file) throws FileNotFoundException {
		super(file);
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param fd
	 */
	public FileInputStream(FileDescriptor fd) {
		super(fd);
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param path
	 * @throws FileNotFoundException
	 */
	public FileInputStream(String path) throws FileNotFoundException {
		super(etalon.purdue.edu.base.wrapper.File.getRootPath() + File.separator + path);
		// TODO Auto-generated constructor stub
	}

}
